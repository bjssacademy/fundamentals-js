// Global scope
//Imagine the largest nesting doll, which represents the global scope. 
//Variables defined in the global scope are accessible from anywhere in your code.
//They are like items placed in the outermost doll that can be seen and accessed by anyone.

let globalVariable = "I'm in the global scope";

function outerFunction() {
  // Function scope (inside outerFunction)
  //Now, picture a smaller nesting doll inside the global one.
  //It represents a function scope. When you define variables or functions within a function, 
  //they become part of that function's scope. 
  //These variables and functions can only be accessed from within that function 
  //or from nested scopes within it.It's like placing items inside this smaller doll, 
  //where they are visible and reachable only inside that specific doll.
  
  let outerVariable = "I'm in the outer function";

  function innerFunction() {
    // Closure/lexical scope (inside innerFunction, but has access to outerFunction's variables)
    let innerVariable = "I'm in the inner function";

    console.log(innerVariable);  // Accessible: innerVariable is defined in the same scope
    console.log(outerVariable);  // Accessible: outerVariable is in the outer scope
    console.log(globalVariable); // Accessible: globalVariable is in the global scope
  }

  innerFunction(); // Call innerFunction
}

outerFunction(); // Call outerFunction

console.log(globalVariable); // Accessible: globalVariable is in the global scope
console.log(outerVariable);  // Not accessible: outerVariable is in the outer function scope
console.log(innerVariable);  // Not accessible: innerVariable is in the inner function scope
