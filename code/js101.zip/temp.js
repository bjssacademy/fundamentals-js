//download and install node.js - https://nodejs.org/en/download 

let x = 10
let y = 20

//task 1
//create a function called addNumbers that will add x and y together
//and print the result

//you do not need to replace the next line, it is the *calling* code
console.log(addNumbers(x, y))


//task 2
//create a function called printNumbers that will print all the numbers between x and y

//you do not need to replace the next line, it is the *calling* code
console.log(printNumbers(x, y))

//task 3
//create a function called isDog that takes a string
//if that string is exactly "dog", "Dog" or any combination
//of different case letters, return true
//in all other instances return false

//you do not need to replace the next 3 lines, it is the *calling* code
console.log(isDog("dog"))
console.log(isDog("Dog"))
console.log(isDog("dOg"))

//Running Your Code
//To run your code, you should be in the terminal in the correct folder
//where you have saved this file
//enter the following in th terminal:
//node temp.js
//amd press Enter

//WRITE YOUR FUNCTIONS UNDER HERE


/*+++++++++BONUS TASK+++++++
The following code produces a random number between 1 and 6:
Math.floor(Math.random() * 6) + 1;

Write a function that accepts a parameter x, and produces x * random numbers. Eg if x was 10, it would produce 10 random numbers.
*/
